# Nexo — resultados

- [x] **Chat y cerebro API:** Nexo conversa en español con la API administrada de Manus; muestra modelos disponibles y realiza llamadas solo desde el backend, sin claves en el navegador.
- [x] **Memoria persistente y separada:** historial comprobado en MySQL administrado, ligado al identificador aleatorio de cada navegador y borrable por conversación.
- [x] **Herramienta y transparencia:** calculadora aritmética limitada probada; interfaz aclara que Nexo no es copia ni modelo GPT-6 entrenado desde cero.
- [x] **Interfaz y recuperación:** interfaz española con diseño responsivo, estados de conexión/carga/error y acción de reintento.
- [ ] **Sitio web permanente:** completar publicación administrada y verificar su URL de producción.
- [ ] **Repositorio GitHub compartido:** enviar los archivos al `main` de `absalonv35-creator/IA`; GitHub devolvió HTTP 403 al intentar el push. El remoto permanece sin cambios.
