# Plan — Nexo

## Objetivo y decisiones
Construir un sitio web público y permanente a partir del prototipo y del repositorio compartido. El repositorio se inspeccionó y contenía solo `.gitignore`, así que se preservan esas reglas y se añaden las del proyecto Node. El sitio usa HTML/CSS/JavaScript, backend Node 22, API de IA administrada por Manus desde el servidor y MySQL administrado para memoria duradera. No hay claves en el navegador ni obligación de instalar Ollama. Las sesiones se separan con un UUID por navegador y el botón de borrado elimina solamente su historial. La calculadora interpreta solo expresiones aritméticas admitidas.

## Capas y archivos
`public/index.html` es estructura y contenido; `public/styles.css` controla la apariencia; `public/app.js` mantiene controles y comunicación con la API del sitio; `app.js` valida solicitudes, administra memoria, llama a Manus y calcula operaciones; `package.json` fija entorno; `Dockerfile` sirve el backend de producción; `public/manus-routes.json` declara rutas; `README.md` explica edición y ejecución.

## Diseño
**Movimiento:** consola editorial contemporánea. **Principios:** claro, honesto, privado por conversación y fácil de editar. **Color:** azul tinta para foco, pizarra para superficies y turquesa propio de Nexo para actividad; coral/ámbar para errores y avisos. **Layout:** cabecera compacta, chat amplio y caja de entrada al pie, sin rejilla decorativa. **Motivos:** marca geométrica N, pulso de conexión y burbujas diferenciadas. **Interacciones:** estados accesibles y reintento de la misma consulta; transiciones breves con respeto a `prefers-reduced-motion`. **Tipografía:** sans-serif del sistema y jerarquía sobria. **Marca:** Nexo es un asistente en español, claro, cercano y transparente. Voz directa: «¿Qué quieres resolver?» y «Este modelo procesa tu mensaje para responder». **Símbolo:** N geométrica con punto de pulso; color distintivo turquesa.

## Alcance del sitio
Chat en español, catálogo de modelos disponibles, conexión por backend, memoria persistente aislada, borrado sencillo, calculadora limitada, explicación de transparencia, carga/error/reintento y diseño móvil/escritorio. La interfaz aclara que no es una copia de GPT-6 ni un modelo entrenado desde cero.
