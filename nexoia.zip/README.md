# Nexo — asistente IA en español

Aplicación web desplegable y editable. Usa la API de IA administrada por Manus desde el servidor, MySQL administrado para guardar el historial y un identificador aleatorio por navegador. No expone credenciales al frontend. Nexo no es GPT-6 ni un modelo entrenado desde cero.

## Abrir y editar el código

Descarga el paquete del proyecto o abre esta carpeta en VS Code, PyCharm u otro editor.

| Archivo | Qué puedes cambiar |
|---|---|
| `public/index.html` | Textos, estructura, aviso de transparencia y controles |
| `public/styles.css` | Colores, tipografía, tamaños y diseño móvil |
| `public/app.js` | Interacción, estados, selector de modelo, historial y reintentos |
| `app.js` | Backend, API Manus, base de datos, prompt y calculadora |
| `package.json` | Dependencias y comandos |
| `Dockerfile` | Construcción y ejecución del sitio publicado |

El repositorio GitHub que compartiste solo contenía su `.gitignore`; lo reutilicé y amplié sin quitar sus reglas. El código completo está en este proyecto y en el paquete fuente descargable para abrirlo o modificarlo desde VS Code. GitHub rechazó el envío de los nuevos archivos con HTTP 403, así que el remoto aún conserva solo sus archivos originales.

## Arquitectura

```text
Navegador → backend Node → API LLM administrada por Manus
                         → MySQL administrado (memoria)
```

El modelo predeterminado usa la ruta administrada por Manus. Los identificadores de modelos disponibles se consultan desde el backend; el navegador nunca recibe las claves. Los mensajes se envían al servicio de IA para responder.

Cada navegador guarda un UUID en `localStorage`; el backend lo utiliza para asociar el historial persistente. No hay cuentas de usuario, así que la conversación no se sincroniza entre dispositivos. **Borrar esta conversación** elimina sus mensajes de la base. Si se borran los datos del navegador, se pierde el identificador local y no se podrá recuperar esa conversación desde ese navegador.

La calculadora analiza únicamente números, paréntesis y `+ - * / %`. No usa `eval`, Python ni ejecución arbitraria de código.

## Ejecutar localmente

Requisitos: Node.js 22+, npm 10.9.2+, una base MySQL compatible y credenciales autorizadas. Copia `.env.example` a `.env` y configura los valores en ese archivo local, nunca en el navegador ni en el repositorio:

```bash
npm ci
npm run check
npm run dev
```

Abre `http://localhost:3000`. El backend necesita `DATABASE_URL`, `MANUS_API_URL` y `MANUS_API_KEY`. En la publicación administrada las variables las proporciona el entorno del proyecto. No se han escrito secretos en archivos.

## Rutas

- `GET /` — interfaz web.
- `GET /api/health` — estado del backend y base de datos.
- `GET /api/models` — catálogo de modelos publicables.
- `GET /api/history?conversationId=<UUID>` — historial de ese navegador.
- `POST /api/chat` — conversación y calculadora.
- `POST /api/reset` — borrar la conversación de ese navegador.
