import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 3000);
const AI_URL = (process.env.MANUS_API_URL || '').replace(/\/$/, '');
const AI_KEY = process.env.MANUS_API_KEY || '';
const DB_URL = process.env.DATABASE_URL || '';
const MAX_CHARS = 8000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SYSTEM = 'Eres Nexo, un asistente personal inteligente que habla español claro. Sé útil, honesto y concreto; no inventes hechos ni afirmes conocer datos privados. Si no sabes algo, dilo. No afirmes ser GPT-6 ni una copia de un modelo propietario. Usa el contexto reciente cuando sea pertinente.';
const modelCache = { ids: [], until: 0 };
let pool;
let databaseReady = false;

if (DB_URL) {
  const db = new URL(DB_URL);
  const tls = [...db.searchParams.keys()].some((key) => /^(ssl|ssl[-_]?mode|tls)/i.test(key));
  pool = mysql.createPool({
    host: db.hostname,
    port: Number(db.port || 3306),
    user: decodeURIComponent(db.username),
    password: decodeURIComponent(db.password),
    database: decodeURIComponent(db.pathname.replace(/^\//, '')),
    waitForConnections: true,
    connectionLimit: 6,
    queueLimit: 0,
    enableKeepAlive: true,
    ssl: tls ? { rejectUnauthorized: true } : undefined,
  });
}

async function initDb() {
  if (!pool) return;
  await pool.query(`CREATE TABLE IF NOT EXISTS conversation_messages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    conversation_id CHAR(36) NOT NULL,
    message_id VARCHAR(80) NOT NULL,
    role ENUM('user','assistant') NOT NULL,
    content MEDIUMTEXT NOT NULL,
    model_id VARCHAR(191) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_message_id (message_id),
    KEY idx_conversation_history (conversation_id, id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  databaseReady = true;
}

function sendJson(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'content-type':'application/json; charset=utf-8', 'content-length':Buffer.byteLength(body), 'cache-control':'no-store', 'x-content-type-options':'nosniff', 'referrer-policy':'no-referrer' });
  res.end(body);
}
function fail(message, status=400) { return Object.assign(new Error(message), { status }); }
async function readBody(req, max=24000) {
  let size=0; const chunks=[];
  for await (const part of req) { size+=part.length; if (size>max) throw fail('La solicitud es demasiado grande.',413); chunks.push(part); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw fail('Formato de solicitud no válido.'); }
}

function calcTokens(text) {
  const tokens=[]; const re=/\s*(?:(\d+(?:\.\d+)?)|([()+\-*/%]))/gy; let i=0;
  while(i<text.length){re.lastIndex=i;const m=re.exec(text);if(!m)throw Error('not math');tokens.push(m[1]??m[2]);i=re.lastIndex;}
  if(!tokens.length||tokens.length>200)throw Error('not math'); return tokens;
}
function evaluate(expression) {
  const t=calcTokens(expression);let p=0;
  function atom(){const x=t[p++];if(x==='+'||x==='-'){const n=atom();return x==='-'?-n:n;}if(x==='('){const n=sum();if(t[p++]!==')')throw Error('paren');return n;}if(x!==undefined&&/^\d+(?:\.\d+)?$/.test(x))return Number(x);throw Error('number');}
  function term(){let n=atom();while(['*','/','%'].includes(t[p])){const op=t[p++],r=atom();if((op==='/'||op==='%')&&r===0)throw Error('zero');n=op==='*'?n*r:op==='/'?n/r:n%r;}return n;}
  function sum(){let n=term();while(t[p]==='+'||t[p]==='-'){const op=t[p++],r=term();n=op==='+'?n+r:n-r;}return n;}
  const n=sum();if(p!==t.length||!Number.isFinite(n)||Math.abs(n)>1e100)throw Error('invalid');return Number(n.toPrecision(12)).toString();
}
function calculator(text) {
  const clean=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  const m=clean.match(/^(?:¿?cuanto es|calcula|resultado de)\s+(.+?)\??$/i)||clean.match(/^([\d\s()+\-*/%.]+)\s*\??$/);
  if(!m||!/^[\d\s()+\-*/%.]+$/.test(m[1].trim()))return null;
  try{return evaluate(m[1].trim());}catch{return null;}
}
async function availableModels() {
  if(!AI_URL||!AI_KEY)return [];
  if(Date.now()<modelCache.until)return modelCache.ids;
  try{
    const r=await fetch(`${AI_URL}/v1/models`,{headers:{authorization:`Bearer ${AI_KEY}`},signal:AbortSignal.timeout(12000)});
    if(!r.ok)return modelCache.ids;
    const body=await r.json();
    modelCache.ids=Array.isArray(body.data)?[...new Set(body.data.map(x=>x?.id).filter(x=>typeof x==='string'&&x.length<192))].sort():[];
    modelCache.until=Date.now()+60000;
  }catch{}
  return modelCache.ids;
}
async function askModel(messages, model) {
  if(!AI_URL||!AI_KEY)throw fail('La API administrada no está disponible todavía.',503);
  const payload={messages,temperature:0.4};
  if(model&&model!=='default'){
    if(!(await availableModels()).includes(model))throw fail('Ese modelo no aparece en el catálogo disponible. Actualiza la página e inténtalo de nuevo.');
    payload.model=model;
  }
  let r;
  try{r=await fetch(`${AI_URL}/v1/chat/completions`,{method:'POST',headers:{authorization:`Bearer ${AI_KEY}`,'content-type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(90000)});}
  catch{throw fail('No se pudo conectar con el servicio de IA. Puedes reintentar el mensaje.',503);}
  const result=await r.json().catch(()=>({}));
  if(!r.ok||result.error){console.error('LLM upstream status:',r.status);throw fail(r.status===429?'El servicio está ocupado. Espera un momento e inténtalo de nuevo.':'El servicio de IA no pudo responder. Comprueba la conexión e inténtalo de nuevo.',r.status===429?429:502);}
  const answer=result?.choices?.[0]?.message?.content;
  if(typeof answer!=='string'||!answer.trim())throw fail('El modelo devolvió una respuesta vacía. Puedes reintentar.',502);
  return answer.trim();
}
async function history(id, limit=80) {
  const safeLimit=Math.max(1,Math.min(100,Number.isInteger(limit)?limit:80));
  const [rows]=await pool.execute(`SELECT role,content,model_id,created_at FROM conversation_messages WHERE conversation_id=? ORDER BY id DESC LIMIT ${safeLimit}`,[id]);
  return rows.reverse().map(x=>({role:x.role,content:x.content,model:x.model_id||null,createdAt:x.created_at}));
}
const files=new Map([['/','index.html'],['/index.html','index.html'],['/app.js','app.js'],['/styles.css','styles.css'],['/nexo-mark.svg','nexo-mark.svg'],['/manus-routes.json','manus-routes.json']]);
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};

const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url||'/', 'http://localhost');
  if(req.method==='GET'&&url.pathname==='/api/health')return sendJson(res,databaseReady?200:503,{ok:databaseReady,database:databaseReady,aiConfigured:Boolean(AI_URL&&AI_KEY)});
  if(req.method==='GET'&&url.pathname==='/api/models'){
    const configured=Boolean(AI_URL&&AI_KEY), ids=configured?await availableModels():[];
    return sendJson(res,configured?200:503,{provider:'Manus AI',configured,models:[{id:'default',name:'Modelo administrado (predeterminado)'},...ids.map(id=>({id,name:id}))]});
  }
  if(req.method==='GET'&&url.pathname==='/api/history'){
    const id=url.searchParams.get('conversationId');if(!UUID.test(id||''))return sendJson(res,400,{error:'Identificador de conversación no válido.'});
    if(!databaseReady)return sendJson(res,503,{error:'La memoria todavía no está disponible.'});
    try{return sendJson(res,200,{messages:await history(id)});}catch{return sendJson(res,503,{error:'No se pudo recuperar la memoria. Vuelve a intentarlo.'});}
  }
  if(req.method==='POST'&&url.pathname==='/api/reset'){
    try{const data=await readBody(req);if(!UUID.test(data.conversationId||''))return sendJson(res,400,{error:'Identificador no válido.'});if(!databaseReady)return sendJson(res,503,{error:'La memoria todavía no está disponible.'});await pool.execute('DELETE FROM conversation_messages WHERE conversation_id=?',[data.conversationId]);return sendJson(res,200,{ok:true});}
    catch(e){return sendJson(res,e.status||503,{error:e.message||'No se pudo borrar la memoria.'});}
  }
  if(req.method==='POST'&&url.pathname==='/api/chat'){
    let stage='read';
    try{
      const d=await readBody(req),{conversationId,requestId,message,model='default'}=d;
      if(!UUID.test(conversationId||'')||!UUID.test(requestId||''))return sendJson(res,400,{error:'Identificador de conversación o solicitud no válido.'});
      if(typeof message!=='string'||!message.trim()||message.length>MAX_CHARS)return sendJson(res,400,{error:`El mensaje debe tener entre 1 y ${MAX_CHARS} caracteres.`});
      if(typeof model!=='string'||model.length>191)return sendJson(res,400,{error:'Modelo no válido.'});
      if(!databaseReady)return sendJson(res,503,{error:'La memoria todavía no está disponible. Inténtalo en unos momentos.'});
      const aid=`${requestId}-assistant`,uid=`${requestId}-user`;
      stage='lookup';
      const [[prior]]=await pool.execute('SELECT content FROM conversation_messages WHERE conversation_id=? AND message_id=?',[conversationId,aid]);
      if(prior)return sendJson(res,200,{reply:prior.content,replayed:true});
      stage='save user';
      await pool.execute("INSERT IGNORE INTO conversation_messages (conversation_id,message_id,role,content,model_id) VALUES (?,?, 'user', ?,?)",[conversationId,uid,message.trim(),model]);
      const result=calculator(message);
      stage=result!==null?'calculator':'load context';
      const context=result===null?await history(conversationId,24):[];
      stage='model';
      const reply=result!==null?`El resultado es ${result}.`:await askModel([{role:'system',content:SYSTEM},...context.map(({role,content})=>({role,content}))],model);
      stage='save assistant';
      await pool.execute("INSERT INTO conversation_messages (conversation_id,message_id,role,content,model_id) VALUES (?,?, 'assistant', ?,?)",[conversationId,aid,reply,model]);
      return sendJson(res,200,{reply});
    }catch(e){console.error('Chat failure stage:',stage,'code:',e.code||e.name,'status:',e.status||500);return sendJson(res,e.status||500,{error:e.message||'Ocurrió un error inesperado. Puedes volver a intentarlo.'});}
  }
  if(req.method==='GET'&&files.has(url.pathname)){
    const name=files.get(url.pathname),filename=path.join(PUBLIC,name);
    return fs.readFile(filename,(err,content)=>{if(err)return sendJson(res,404,{error:'No encontrado.'});res.writeHead(200,{'content-type':mime[path.extname(name)]||'application/octet-stream','content-length':content.length,'x-content-type-options':'nosniff','referrer-policy':'no-referrer','cache-control':name==='index.html'?'no-cache':'public, max-age=300'});res.end(content);});
  }
  return sendJson(res,404,{error:'No encontrado.'});
});

async function start(){try{await initDb();console.log('Almacenamiento persistente listo.');}catch(e){console.error('Base administrada no lista:',e.message);}server.listen(PORT,'0.0.0.0',()=>console.log(`Nexo listo en puerto ${PORT}.`));}
process.on('SIGTERM',async()=>{server.close();if(pool)await pool.end().catch(()=>{});process.exit(0);});
start();
